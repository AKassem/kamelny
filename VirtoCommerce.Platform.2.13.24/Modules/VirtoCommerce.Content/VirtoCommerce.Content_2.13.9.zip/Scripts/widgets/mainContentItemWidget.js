﻿angular.module('virtoCommerce.contentModule')
.controller('virtoCommerce.contentModule.mainContentItemWidgetController', ['$state', '$scope', 'platformWebApp.bladeNavigationService', function ($state, $scope, bladeNavigationService) {
}]);
